
#ifndef READ_CONFIG_H
# define READ_CONFIG_H

/*** DEFINES ***/

# define RC_FILE ".minishrc"

/*** PROTOTYPES ***/

/* read_config.c */
void	read_config(void);

#endif
