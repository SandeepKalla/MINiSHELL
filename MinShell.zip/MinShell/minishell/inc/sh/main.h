
#ifndef MAIN_H
# define MAIN_H

/*** INCLUDES ***/

# include <libft/ft_bool.h>

/*** PROTOTYPES ***/

void	handle_line(char *line, t_bool is_alloc);

#endif
