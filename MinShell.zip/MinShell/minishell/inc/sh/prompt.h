
#ifndef PROMPT_H
# define PROMPT_H

/*** PROTOYPES ***/

/* prompt/prompt.c */
char	*read_prompt(void);

/* prompt/init_prompt.c */
void	init_prompt(void);

#endif
